(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["main"],{

/***/ "./src/$$_lazy_route_resource lazy recursive":
/*!**********************************************************!*\
  !*** ./src/$$_lazy_route_resource lazy namespace object ***!
  \**********************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

function webpackEmptyAsyncContext(req) {
	// Here Promise.resolve().then() is used instead of new Promise() to prevent
	// uncaught exception popping up in devtools
	return Promise.resolve().then(function() {
		var e = new Error("Cannot find module '" + req + "'");
		e.code = 'MODULE_NOT_FOUND';
		throw e;
	});
}
webpackEmptyAsyncContext.keys = function() { return []; };
webpackEmptyAsyncContext.resolve = webpackEmptyAsyncContext;
module.exports = webpackEmptyAsyncContext;
webpackEmptyAsyncContext.id = "./src/$$_lazy_route_resource lazy recursive";

/***/ }),

/***/ "./src/app/app-routing.module.ts":
/*!***************************************!*\
  !*** ./src/app/app-routing.module.ts ***!
  \***************************************/
/*! exports provided: AppRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AppRoutingModule", function() { return AppRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");



var routes = [];
var AppRoutingModule = /** @class */ (function () {
    function AppRoutingModule() {
    }
    AppRoutingModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
            imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forRoot(routes)],
            exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]]
        })
    ], AppRoutingModule);
    return AppRoutingModule;
}());



/***/ }),

/***/ "./src/app/app.component.css":
/*!***********************************!*\
  !*** ./src/app/app.component.css ***!
  \***********************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL2FwcC5jb21wb25lbnQuY3NzIn0= */"

/***/ }),

/***/ "./src/app/app.component.html":
/*!************************************!*\
  !*** ./src/app/app.component.html ***!
  \************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<!-- <form [formGroup]= \"myForm\">\n  <label for=\"firstname\">First Name</label><br>\n  <input type=\"text\" formControlName=\"firstname\"/><br>\n  <div *ngFor =\"let f of error_messages.firstname\">\n    <div *ngIf=\"myForm.get('firstname').hasError(f.type) && (myForm.get('firstname').touched || myForm.get('firstname').dirty)\">\n     <b [ngStyle]=\"{color:'red'}\"> {{f.message}}</b>\n    </div>\n  </div>\n  <label for=\"lastname\">Last Name</label><br>\n  <input type=\"text\" formControlName=\"lastname\"/><br>\n  <div *ngFor =\"let f of error_messages.lastname\">\n    <div *ngIf=\"myForm.get('lastname').hasError(f.type) && (myForm.get('lastname').touched || myForm.get('lastname').dirty)\">\n     <b [ngStyle]=\"{color:'red'}\"> {{f.message}}</b>\n    </div>\n  </div>\n\n \n  <label for=\"email\">Email</label><br>\n  <input type=\"text\" formControlName=\"email\"/><br>\n\n  <div *ngFor =\"let f of error_messages.email\">\n    <div *ngIf=\"myForm.get('email').hasError(f.type) && (myForm.get('email').touched || myForm.get('email').dirty)\">\n     <b [ngStyle]=\"{color:'red'}\"> {{f.message}}</b>\n    </div>\n  </div>\n  \n  <label for=\"phoneno\">PhoneNo</label><br>\n  <input type=\"number\" formControlName=\"phoneno\"/><br>\n  <div *ngFor =\"let f of error_messages.phoneno\">\n    <div *ngIf=\"myForm.get('phoneno').hasError(f.type) && (myForm.get('phoneno').touched || myForm.get('phoneno').dirty)\">\n     <b [ngStyle]=\"{color:'red'}\"> {{f.message}}</b>\n    </div>\n  </div>\n\n\n      <label for=\"gender\">Gender</label><br>\n    <input type=\"radio\" value=\"Male\" formControlName=\"gender\"/>Male\n  \n    <input type=\"radio\" value=\"Female\" formControlName=\"gender\"/>Female<br>\n    <div *ngFor =\"let f of error_messages.gender\">\n        <div *ngIf=\"myForm.get('gender').hasError(f.type) && (myForm.get('gender').touched || myForm.get('gender').dirty)\">\n         <b [ngStyle]=\"{color:'red'}\"> {{f.message}}</b>\n        </div>\n      </div>\n \n    <label for=\"lang\">languages</label><br>\n    <input type=\"checkbox\" formControlName=\"lang\"/>Java\n  \n    <input type=\"checkbox\"  formControlName=\"lang\"/>Pega<br>\n   \n    <div *ngFor =\"let f of error_messages.lang\">\n        <div *ngIf=\"myForm.get('lang').hasError(f.type) && (myForm.get('lang').touched || myForm.get('lang').dirty)\">\n         <b [ngStyle]=\"{color:'red'}\"> {{f.message}}</b>\n        </div>\n      </div> \n\n\n      <div formGroupName=\"address\">\n        <label for=\"city\">\n        City:\n        </label>\n        <input type=\"text\" formControlName=\"city\"/><br>\n        <div *ngFor =\"let f of error_messages.city\">\n            <div *ngIf=\"myForm.get('address').get('city').hasError(f.type) \">\n             <b [ngStyle]=\"{color:'red'}\"> {{f.message}}</b>\n            </div>\n          </div>\n        <label for=\"state\">\n            State:\n            </label> \n            <input type=\"text\" formControlName=\"state\"/><br>\n\n       \n          <div *ngFor =\"let f of error_messages.state\">\n              <div *ngIf=\"myForm.get('address').get('state').hasError(f.type) \">\n               <b [ngStyle]=\"{color:'red'}\"> {{f.message}}</b>\n              </div>\n            </div>\n            </div>\n  <button type=\"submit\"[disabled]=!myForm.valid>Submit</button> -->\n\n  <app-products></app-products>"

/***/ }),

/***/ "./src/app/app.component.ts":
/*!**********************************!*\
  !*** ./src/app/app.component.ts ***!
  \**********************************/
/*! exports provided: AppComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AppComponent", function() { return AppComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");



var AppComponent = /** @class */ (function () {
    function AppComponent() {
        this.title = 'ng-forms-app';
        this.myForm = new _angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormGroup"]({
            firstname: new _angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormControl"]('', [_angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required, _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].minLength(3), _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].maxLength(10)]),
            lastname: new _angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormControl"]('', [_angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required, _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].minLength(3), _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].maxLength(10)]),
            email: new _angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormControl"]('', [_angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required, _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].pattern(/^[a-z]+[a-z0-9._]+@[a-z]+\.[a-z.]{2,5}$/)]),
            phoneno: new _angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormControl"]('', [_angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required, _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].pattern(/(7|8|9)\d{9}/)]),
            gender: new _angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormControl"]('', [_angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required]),
            lang: new _angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormControl"]('', [_angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required]),
            address: new _angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormGroup"]({ city: new _angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormControl"]('', [_angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required]),
                state: new _angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormControl"]('', [_angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required]) })
        });
        this.error_messages = {
            'firstname': [{ type: 'required', message: "Field should not be empty" },
                { type: 'maxlength', message: "it should be maximum of ten charectors" },
                { type: 'minlength', message: "it should be minimum of three charectors" },
            ],
            'lastname': [{ type: 'required', message: "Field should not be empty" },
                { type: 'maxlength', message: "it should be maximum of ten charectors" },
                { type: 'minlength', message: "it should be minimum of three charectors" }],
            'city': [{ type: 'required', message: "Field should not be empty" }],
            'state': [{ type: 'required', message: "Field should not be empty" }],
            'email': [{ type: 'required', message: "Field should not be empty" },
                { type: 'pattern', message: "it should contain special charector" }],
            'phoneno': [{ type: 'required', message: "Field should not be empty" },
                { type: 'pattern', message: "it should contain 7(or) 8(or) 9 as first number and should have 10 digits" }],
            'gender': [{ type: 'required', message: "Field should not be empty" }],
            'lang': [{ type: 'required', message: "Field should not be empty" }]
        };
    }
    AppComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-root',
            template: __webpack_require__(/*! ./app.component.html */ "./src/app/app.component.html"),
            styles: [__webpack_require__(/*! ./app.component.css */ "./src/app/app.component.css")]
        })
    ], AppComponent);
    return AppComponent;
}());



/***/ }),

/***/ "./src/app/app.module.ts":
/*!*******************************!*\
  !*** ./src/app/app.module.ts ***!
  \*******************************/
/*! exports provided: AppModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AppModule", function() { return AppModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_platform_browser__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/platform-browser */ "./node_modules/@angular/platform-browser/fesm5/platform-browser.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var _app_routing_module__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./app-routing.module */ "./src/app/app-routing.module.ts");
/* harmony import */ var _app_component__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./app.component */ "./src/app/app.component.ts");
/* harmony import */ var _products_products_component__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./products/products.component */ "./src/app/products/products.component.ts");
/* harmony import */ var ngx_pagination__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ngx-pagination */ "./node_modules/ngx-pagination/dist/ngx-pagination.js");








var AppModule = /** @class */ (function () {
    function AppModule() {
    }
    AppModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_2__["NgModule"])({
            declarations: [
                _app_component__WEBPACK_IMPORTED_MODULE_5__["AppComponent"],
                _products_products_component__WEBPACK_IMPORTED_MODULE_6__["ProductsComponent"],
            ],
            imports: [
                _angular_platform_browser__WEBPACK_IMPORTED_MODULE_1__["BrowserModule"],
                _app_routing_module__WEBPACK_IMPORTED_MODULE_4__["AppRoutingModule"],
                _angular_forms__WEBPACK_IMPORTED_MODULE_3__["ReactiveFormsModule"],
                _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
                ngx_pagination__WEBPACK_IMPORTED_MODULE_7__["NgxPaginationModule"]
            ],
            providers: [],
            bootstrap: [_app_component__WEBPACK_IMPORTED_MODULE_5__["AppComponent"]]
        })
    ], AppModule);
    return AppModule;
}());



/***/ }),

/***/ "./src/app/product.service.ts":
/*!************************************!*\
  !*** ./src/app/product.service.ts ***!
  \************************************/
/*! exports provided: ProductService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ProductService", function() { return ProductService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");


var ProductService = /** @class */ (function () {
    function ProductService() {
    }
    ProductService.prototype.getAllProducts = function () {
        return [
            { id: 1, name: 'Redmi ', model: 'Note 4', price: 9000 },
            { id: 2, name: 'Vivo', model: 'Note 4', price: 9000 },
            { id: 3, name: 'Oppo', model: 'Note 4', price: 9000 },
            { id: 4, name: 'Moto', model: 'Note 4', price: 9000 },
            { id: 5, name: 'Samsung ', model: 'Note 4', price: 9000 },
            { id: 6, name: 'Honor', model: 'Note 4', price: 9000 },
            { id: 7, name: 'Iphone', model: 'Note 4', price: 9000 },
            { id: 8, name: 'One Plus ', model: 'Note 4', price: 9000 },
            { id: 9, name: 'Nokia ', model: 'Note 4', price: 9000 },
            { id: 10, name: 'Real ME', model: 'Note 4', price: 9000 }
        ];
    };
    ProductService = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
            providedIn: 'root'
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [])
    ], ProductService);
    return ProductService;
}());



/***/ }),

/***/ "./src/app/products/products.component.css":
/*!*************************************************!*\
  !*** ./src/app/products/products.component.css ***!
  \*************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL3Byb2R1Y3RzL3Byb2R1Y3RzLmNvbXBvbmVudC5jc3MifQ== */"

/***/ }),

/***/ "./src/app/products/products.component.html":
/*!**************************************************!*\
  !*** ./src/app/products/products.component.html ***!
  \**************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = " <table border='1'>\n    <thead>\n      <tr>\n        <th>Id</th>\n        <th>Name</th>\n        <th>Model</th>\n        <th>Price</th>\n      </tr>\n    </thead>\n    <tbody>\n      <tr *ngFor=\"let p of products|  paginate:{itemsPerPage:opt,currentPage:p}\">\n        <td>{{p.id}}</td>\n        <td>{{p.name}}</td>\n        <td>{{p.model}}</td>\n        <td>{{p.price}}</td>\n      </tr>\n    </tbody>\n  </table>\n  <pagination-controls (pageChange) =\"p=$event\"></pagination-controls>\n  <br>\n  <br> \n  <select [(ngModel)]=\"opt\">\n      <option value=\"5\">5</option>\n      <option value=\"10\">10</option>\n      \n  </select>\n   <br>\n  <!-- <div [ngSwitch]=\"opt\">\n    <div *ngSwitchCase=\"'5'\">\n        <table border='1'>\n            <thead>\n              <tr>\n                <th>Id</th>\n                <th>Name</th>\n                <th>Model</th>\n                <th>Price</th>\n              </tr>\n            </thead>\n            <tbody>\n              <tr *ngFor=\"let p of products|  paginate:{itemsPerPage:5,currentPage:p}\">\n                <td>{{p.id}}</td>\n                <td>{{p.name}}</td>\n                <td>{{p.model}}</td>\n                <td>{{p.price}}</td>\n              </tr>\n            </tbody>\n          </table>\n    </div>\n    <div *ngSwitchCase=\"'10'\">\n        <table border='1'>\n            <thead>\n              <tr>\n                <th>Id</th>\n                <th>Name</th>\n                <th>Model</th>\n                <th>Price</th>\n              </tr>\n            </thead>\n            <tbody>\n              <tr *ngFor=\"let p of products|  paginate:{itemsPerPage:10,currentPage:p}\">\n                <td>{{p.id}}</td>\n                <td>{{p.name}}</td>\n                <td>{{p.model}}</td>\n                <td>{{p.price}}</td>\n              </tr>\n            </tbody>\n          </table>\n\n    </div>\n    <div *ngSwitchDefault>Please Choose a Language</div> \n  </div> -->"

/***/ }),

/***/ "./src/app/products/products.component.ts":
/*!************************************************!*\
  !*** ./src/app/products/products.component.ts ***!
  \************************************************/
/*! exports provided: ProductsComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ProductsComponent", function() { return ProductsComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _product_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../product.service */ "./src/app/product.service.ts");



var ProductsComponent = /** @class */ (function () {
    function ProductsComponent(pservice) {
        this.pservice = pservice;
        this.products = [];
        this.products = pservice.getAllProducts();
    }
    ProductsComponent.prototype.ngOnInit = function () {
    };
    ProductsComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-products',
            template: __webpack_require__(/*! ./products.component.html */ "./src/app/products/products.component.html"),
            styles: [__webpack_require__(/*! ./products.component.css */ "./src/app/products/products.component.css")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_product_service__WEBPACK_IMPORTED_MODULE_2__["ProductService"]])
    ], ProductsComponent);
    return ProductsComponent;
}());



/***/ }),

/***/ "./src/environments/environment.ts":
/*!*****************************************!*\
  !*** ./src/environments/environment.ts ***!
  \*****************************************/
/*! exports provided: environment */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "environment", function() { return environment; });
// This file can be replaced during build by using the `fileReplacements` array.
// `ng build --prod` replaces `environment.ts` with `environment.prod.ts`.
// The list of file replacements can be found in `angular.json`.
var environment = {
    production: false
};
/*
 * For easier debugging in development mode, you can import the following file
 * to ignore zone related error stack frames such as `zone.run`, `zoneDelegate.invokeTask`.
 *
 * This import should be commented out in production mode because it will have a negative impact
 * on performance if an error is thrown.
 */
// import 'zone.js/dist/zone-error';  // Included with Angular CLI.


/***/ }),

/***/ "./src/main.ts":
/*!*********************!*\
  !*** ./src/main.ts ***!
  \*********************/
/*! no exports provided */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_platform_browser_dynamic__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/platform-browser-dynamic */ "./node_modules/@angular/platform-browser-dynamic/fesm5/platform-browser-dynamic.js");
/* harmony import */ var _app_app_module__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./app/app.module */ "./src/app/app.module.ts");
/* harmony import */ var _environments_environment__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./environments/environment */ "./src/environments/environment.ts");




if (_environments_environment__WEBPACK_IMPORTED_MODULE_3__["environment"].production) {
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["enableProdMode"])();
}
Object(_angular_platform_browser_dynamic__WEBPACK_IMPORTED_MODULE_1__["platformBrowserDynamic"])().bootstrapModule(_app_app_module__WEBPACK_IMPORTED_MODULE_2__["AppModule"])
    .catch(function (err) { return console.error(err); });


/***/ }),

/***/ 0:
/*!***************************!*\
  !*** multi ./src/main.ts ***!
  \***************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__(/*! D:\TOPUP\Angular\ng-forms-app\src\main.ts */"./src/main.ts");


/***/ })

},[[0,"runtime","vendor"]]]);
//# sourceMappingURL=main.js.map